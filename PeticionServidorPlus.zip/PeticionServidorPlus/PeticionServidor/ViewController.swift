//
//  ViewController.swift
//  PeticionServidor
//
//  Created by LEONEL HERNANDEZ PEREZ on 05/04/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wISBN: UITextField!
    @IBOutlet weak var wSalida: UITextView!
    @IBOutlet weak var wAutor: UILabel!
    @IBOutlet weak var wTitulo: UILabel!

    
    @IBAction func fLimpia(_ sender: Any) {
        wISBN.text = ""
    }
    
    @IBAction func Busca(_ sender: Any) {

        let wTex:String = wISBN.text!
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(wTex)"

        let url = NSURL(string: urls)
        //let datos:NSData? = NSData(contentsOf: url! as URL)
            let datos = NSData(contentsOf: url! as URL)
        let texto = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
        print(texto!)
        wSalida.text = texto! as String
        
        
        do{
            let json  = try JSONSerialization.jsonObject(with: datos! as Data, options: .mutableLeaves)
            let dico1 = json                    as! NSDictionary
            let dico2 = dico1["ISBN:978-84-376-0494-7"]          as! NSDictionary
            //let dico3 = dico2["identifiers"]        as! NSDictionary
            self.wTitulo.text = dico2["title"]   as! NSString as String
            self.wAutor.text = dico2["by_statement"]   as! NSString as String
            
            //
            // let dico4 = dico3["channel"]        as! NSDictionary
            // let dico5 = dico4["location"]       as! NSDictionary
            // let dico5 = dico4["units"]       as! NSDictionary
            // self.wCiudad.text = dico5["city"]   as! NSString as String
            // self.wCiudad.text = dico5["distance"]   as! NSString as String
        }
        catch _ {
            
        }
    }
    
        
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

